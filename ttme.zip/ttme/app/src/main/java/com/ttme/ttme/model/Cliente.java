package com.ttme.ttme.model;

import java.util.List;

public class Cliente {
    private String nome;
    private String email;
    private String nameTag;
    private String senha;
    private List <Contato> listClientes;

    public Cliente( String nome, String nameTag) {
        this.nome = nome;
        this.nameTag = nameTag;
    }

    public List<Contato> getListClientes() {
        return listClientes;
    }

    public void setListClientes(List<Contato> listClientes) {
        this.listClientes = listClientes;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Cliente() {
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNameTag() {
        return nameTag;
    }

    public void setNameTag(String nameTag) {
        this.nameTag = nameTag;
    }
}

package com.ttme.ttme;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;

import static com.ttme.ttme.MainActivity.firebaseAuth;

public class login extends AppCompatActivity {
    private TextInputLayout textinputEmail;
    private TextInputLayout textInputSenha;
    private Button buttonlogar;
    private Intent intentIrMain;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        intentIrMain = new Intent(login.this, MainActivity.class);
        inicializaComponentes();
        logar();

    }
    void inicializaComponentes(){
        textinputEmail = findViewById(R.id.textInputEmailLogar);
        textInputSenha = findViewById(R.id.textInputSenhalogar);
        buttonlogar = findViewById(R.id.buttonlogar);

    }

    void logar(){
        buttonlogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firebaseAuth.signInWithEmailAndPassword(textinputEmail.getEditText().getText().toString(), textInputSenha.getEditText().getText().toString())
                        .addOnCompleteListener(login.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(Task<AuthResult> task) {
                                if(task.isSuccessful()){
                                    Toast.makeText(login.this, "Logado", Toast.LENGTH_LONG).show();
                                    startActivity(intentIrMain);

                                }else {
                                    Toast.makeText(login.this, "Não foi possivel logar, revise as informações", Toast.LENGTH_LONG).show();
                                }
                            }
                        });
            }
        });

    }
}
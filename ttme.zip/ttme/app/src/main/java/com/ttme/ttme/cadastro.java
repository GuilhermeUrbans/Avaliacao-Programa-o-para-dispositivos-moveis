package com.ttme.ttme;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.database.DatabaseReference;
import com.ttme.ttme.model.Cliente;

import static com.ttme.ttme.MainActivity.firebaseAuth;
import static com.ttme.ttme.MainActivity.firebaseDatabase;

public class cadastro extends AppCompatActivity {
    private TextInputLayout textinputEmail;
    private TextInputLayout textInputSenha;
    private TextInputLayout textInputSenhaConf;
    private TextInputLayout textInputNome;
    private TextInputLayout textInputNameTag;
    private Button buttonenviarCadatro;
    private DatabaseReference databaseReferenceUser = firebaseDatabase.getReference("user");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);
        inicializaComponentes();
        cadastrarUsuarios();

    }

    void inicializaComponentes(){
        textinputEmail = findViewById(R.id.textFieldEmail);
        textInputSenha = findViewById(R.id.textFieldSenha);
        textInputSenhaConf = findViewById(R.id.textFieldSenhaConf);
        textInputNome = findViewById(R.id.textFieldNomeCadastro);
        textInputNameTag = findViewById(R.id.textFieldNameTag);
        buttonenviarCadatro = findViewById(R.id.buttonEnviarCadastro);
    }

    void cadastrarUsuarios(){
        buttonenviarCadatro.setOnClickListener(new View.OnClickListener() {
            @Override


            public void onClick(View view) {
                Cliente cliente = new Cliente();
                cliente.setNome(textInputNome.getEditText().getText().toString());
                cliente.setNameTag(textInputNameTag.getEditText().getText().toString());
                cliente.setSenha(textInputSenha.getEditText().getText().toString());
                cliente.setEmail(textinputEmail.getEditText().getText().toString());

                //Usar instancia firebaseAuth
                firebaseAuth.createUserWithEmailAndPassword(textinputEmail.getEditText().getText().toString(), textInputSenha.getEditText().getText().toString())
                        .addOnCompleteListener( cadastro.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    databaseReferenceUser.push().setValue(cliente);//Envia para o banco de dados
                                    Toast.makeText(cadastro.this, "Login criado", Toast.LENGTH_LONG).show();
                                } else {
                                    Toast.makeText(cadastro.this, "Não foi possivel cadatrar, revise as informações", Toast.LENGTH_LONG).show();
                                }
                            }
                        });
                //fim
            }
        });
    }
}
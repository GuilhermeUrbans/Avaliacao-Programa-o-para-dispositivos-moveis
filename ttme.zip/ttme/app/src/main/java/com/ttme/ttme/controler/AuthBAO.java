package com.ttme.ttme.controler;

import android.app.Activity;
import android.content.Context;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.ttme.ttme.cadastro;

public class AuthBAO {
    private FirebaseAuth firebaseAuth;

    private FirebaseAuth getInstAuth() {
        return firebaseAuth = FirebaseAuth.getInstance();

    }

    public void addUser(Activity activity, String email, String senha) {
        getInstAuth().createUserWithEmailAndPassword(email, senha)
                .addOnCompleteListener( activity, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(activity, "Login criado", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(activity, "Não foi possivel cadatrar, revise as informações", Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }
}
